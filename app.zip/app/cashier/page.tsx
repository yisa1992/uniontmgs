"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import type { SessionUser } from "@/lib/types";

export default function CashierPage() {
  const router = useRouter();
  const [user, setUser] = useState<SessionUser | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const [ftNumber, setFtNumber] = useState("");
  const [totalAmount, setTotalAmount] = useState("");
  const [restaurant, setRestaurant] = useState("");
  const [cafe, setCafe] = useState("");
  const [butchery, setButchery] = useState("");
  const [tip, setTip] = useState("");
  const [senderName, setSenderName] = useState("");
  const [receiverName, setReceiverName] = useState("");
  const [ftExists, setFtExists] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => {
        if (!r.ok) {
          router.push("/login");
          return null;
        }
        return r.json();
      })
      .then((d) => {
        if (d?.user) {
          if (d.user.role !== "cashier") {
            router.push("/");
            return;
          }
          setUser(d.user);
        }
      });
  }, [router]);

  const autoTip = useCallback(() => {
    const total = parseFloat(totalAmount) || 0;
    const r = parseFloat(restaurant) || 0;
    const c = parseFloat(cafe) || 0;
    const b = parseFloat(butchery) || 0;
    const computed = Math.round((total - r - c - b) * 100) / 100;
    setTip(computed >= 0 ? String(computed) : "0");
  }, [totalAmount, restaurant, cafe, butchery]);

  useEffect(() => {
    if (totalAmount) autoTip();
  }, [totalAmount, restaurant, cafe, butchery, autoTip]);

  useEffect(() => {
    if (!ftNumber || ftNumber.length < 3) {
      setFtExists(false);
      return;
    }
    const t = setTimeout(() => {
      fetch(`/api/transactions?ft=${encodeURIComponent(ftNumber)}`)
        .then((r) => r.json())
        .then((d) => setFtExists(!!d.exists))
        .catch(() => {});
    }, 400);
    return () => clearTimeout(t);
  }, [ftNumber]);

  async function handleImage(file: File) {
    setError("");
    setSuccess("");
    const reader = new FileReader();
    reader.onload = async (e) => {
      const dataUrl = e.target?.result as string;
      setImagePreview(dataUrl);
      setScanning(true);
      try {
        const Tesseract = (await import("tesseract.js")).default;
        const result = await Tesseract.recognize(dataUrl, "eng", {
          logger: () => {},
        });
        parseOcrText(result.data.text);
      } catch {
        setError("OCR failed. Please enter FT number and amount manually.");
      } finally {
        setScanning(false);
      }
    };
    reader.readAsDataURL(file);
  }

  function parseOcrText(text: string) {
    const ftPatterns = [
      /FT\s*[#:.\-]?\s*([A-Z0-9]{8,20})/i,
      /(?:reference|ref|txn|transaction)\s*(?:no|number|#)?[:.\s]*([A-Z0-9]{8,20})/i,
      /\b([A-Z]{2,3}\d{8,16})\b/,
    ];
    for (const p of ftPatterns) {
      const m = text.match(p);
      if (m) {
        setFtNumber(m[1].toUpperCase());
        break;
      }
    }

    const amountPatterns = [
      /(?:total|amount|sum|etb|birr)\s*[:.\s]*([\d,]+\.?\d*)/i,
      /([\d,]+\.\d{2})\s*(?:etb|birr)?/i,
      /([\d,]{3,})\b/,
    ];
    for (const p of amountPatterns) {
      const m = text.match(p);
      if (m) {
        const num = m[1].replace(/,/g, "");
        if (!isNaN(parseFloat(num)) && parseFloat(num) > 0) {
          setTotalAmount(num);
          break;
        }
      }
    }

    const senderMatch = text.match(
      /(?:from|sender|payer|account\s*name)\s*[:.\s]*([A-Za-z\s]{3,40})/i
    );
    if (senderMatch) setSenderName(senderMatch[1].trim());

    const receiverMatch = text.match(
      /(?:to|receiver|beneficiary|credited)\s*[:.\s]*([A-Za-z\s]{3,40})/i
    );
    if (receiverMatch) setReceiverName(receiverMatch[1].trim());
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSuccess("");
    if (ftExists) {
      setError("FT number already exists in the system");
      return;
    }
    const total = parseFloat(totalAmount) || 0;
    const r = parseFloat(restaurant) || 0;
    const c = parseFloat(cafe) || 0;
    const b = parseFloat(butchery) || 0;
    const t = parseFloat(tip) || 0;
    if (Math.abs(r + c + b + t - total) > 0.01) {
      setError(
        `Sum (${(r + c + b + t).toFixed(2)}) must equal scanned amount (${total.toFixed(2)})`
      );
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ftNumber,
          totalAmount: total,
          restaurantAmount: r,
          cafeAmount: c,
          butcheryAmount: b,
          tip: t,
          senderName,
          receiverName,
          imageData: imagePreview || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to save transaction");
        setSubmitting(false);
        return;
      }
      setSuccess(
        `Transaction saved! FT: ${data.transaction.ftNumber} — Auditor has been notified.`
      );
      setFtNumber("");
      setTotalAmount("");
      setRestaurant("");
      setCafe("");
      setButchery("");
      setTip("");
      setSenderName("");
      setReceiverName("");
      setImagePreview(null);
      setFtExists(false);
      if (fileRef.current) fileRef.current.value = "";
    } catch {
      setError("Network error");
    } finally {
      setSubmitting(false);
    }
  }

  if (!user) {
    return (
      <div style={{ padding: "3rem", textAlign: "center", color: "var(--muted)" }}>
        Loading…
      </div>
    );
  }

  const sum =
    (parseFloat(restaurant) || 0) +
    (parseFloat(cafe) || 0) +
    (parseFloat(butchery) || 0) +
    (parseFloat(tip) || 0);
  const total = parseFloat(totalAmount) || 0;
  const balanced = Math.abs(sum - total) < 0.01 && total > 0;

  return (
    <div>
      <Navbar user={user} />
      <main style={{ maxWidth: 900, margin: "0 auto", padding: "1.5rem" }}>
        <h1 style={{ margin: "0 0 0.25rem", fontSize: "1.5rem" }}>
          New Transaction
        </h1>
        <p style={{ color: "var(--muted)", marginBottom: "1.5rem", fontSize: "0.9rem" }}>
          Upload a receipt image to auto-scan FT number &amp; amount, then split into categories.
        </p>

        {error && (
          <div className="alert alert-error" style={{ marginBottom: "1rem" }}>
            {error}
          </div>
        )}
        {success && (
          <div className="alert alert-success" style={{ marginBottom: "1rem" }}>
            {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="card" style={{ padding: "1.25rem", marginBottom: "1.25rem" }}>
            <label className="label">Transaction Image</label>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleImage(f);
              }}
              className="input"
              style={{ padding: "0.5rem" }}
            />
            {scanning && (
              <p style={{ color: "var(--primary)", marginTop: "0.75rem", fontSize: "0.875rem" }}>
                Scanning image with OCR… please wait
              </p>
            )}
            {imagePreview && (
              <div style={{ marginTop: "1rem" }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={imagePreview}
                  alt="Receipt"
                  style={{
                    maxWidth: "100%",
                    maxHeight: 280,
                    borderRadius: 8,
                    border: "1px solid var(--border)",
                  }}
                />
              </div>
            )}
          </div>

          <div className="card" style={{ padding: "1.25rem", marginBottom: "1.25rem" }}>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "1rem",
              }}
            >
              <div>
                <label className="label">FT Number *</label>
                <input
                  className="input"
                  value={ftNumber}
                  onChange={(e) => setFtNumber(e.target.value.toUpperCase())}
                  placeholder="e.g. FT1234567890"
                  required
                  style={
                    ftExists
                      ? { borderColor: "var(--danger)", background: "#fef2f2" }
                      : undefined
                  }
                />
                {ftExists && (
                  <p style={{ color: "var(--danger)", fontSize: "0.8rem", margin: "0.35rem 0 0" }}>
                    This FT number already exists
                  </p>
                )}
              </div>
              <div>
                <label className="label">Scanned Total Amount (ETB) *</label>
                <input
                  className="input"
                  type="number"
                  step="0.01"
                  min="0"
                  value={totalAmount}
                  onChange={(e) => setTotalAmount(e.target.value)}
                  placeholder="0.00"
                  required
                />
              </div>
              <div>
                <label className="label">Sender Name</label>
                <input
                  className="input"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="From OCR or manual"
                />
              </div>
              <div>
                <label className="label">Receiver Account Name</label>
                <input
                  className="input"
                  value={receiverName}
                  onChange={(e) => setReceiverName(e.target.value)}
                  placeholder="From OCR or manual"
                />
              </div>
            </div>
          </div>

          <div className="card" style={{ padding: "1.25rem", marginBottom: "1.25rem" }}>
            <h3 style={{ margin: "0 0 1rem", fontSize: "1rem" }}>Split Amounts</h3>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "1rem",
              }}
            >
              <div>
                <label className="label">Restaurant Amount</label>
                <input
                  className="input"
                  type="number"
                  step="0.01"
                  min="0"
                  value={restaurant}
                  onChange={(e) => setRestaurant(e.target.value)}
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="label">Cafe Amount</label>
                <input
                  className="input"
                  type="number"
                  step="0.01"
                  min="0"
                  value={cafe}
                  onChange={(e) => setCafe(e.target.value)}
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="label">Butchery Amount</label>
                <input
                  className="input"
                  type="number"
                  step="0.01"
                  min="0"
                  value={butchery}
                  onChange={(e) => setButchery(e.target.value)}
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="label">Tip (auto-calculated)</label>
                <input
                  className="input"
                  type="number"
                  step="0.01"
                  value={tip}
                  onChange={(e) => setTip(e.target.value)}
                  placeholder="0.00"
                  style={{ background: "#f8fafc" }}
                />
              </div>
            </div>

            <div
              style={{
                marginTop: "1.25rem",
                padding: "0.875rem 1rem",
                borderRadius: 8,
                background: balanced ? "#ecfdf5" : "#fef3c7",
                border: `1px solid ${balanced ? "#a7f3d0" : "#fcd34d"}`,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                fontSize: "0.9rem",
              }}
            >
              <span>
                Sum: <strong>{sum.toFixed(2)}</strong> / Total:{" "}
                <strong>{total.toFixed(2)}</strong>
              </span>
              <span
                style={{
                  fontWeight: 600,
                  color: balanced ? "var(--success)" : "var(--warning)",
                }}
              >
                {balanced ? "✓ Balanced" : "⚠ Must equal total"}
              </span>
            </div>
          </div>

          <button
            type="submit"
            className="btn btn-success"
            style={{ width: "100%", padding: "0.85rem", fontSize: "1rem" }}
            disabled={submitting || ftExists || !balanced || !ftNumber}
          >
            {submitting ? "Saving…" : "Submit Transaction"}
          </button>
        </form>
      </main>
    </div>
  );
}
